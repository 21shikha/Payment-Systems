package com.barclays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication

public class Barclays_Payments_Project {

	public static void main(String[] args) {
		SpringApplication.run(Barclays_Payments_Project.class, args);
	}

}
