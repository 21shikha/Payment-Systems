package com.barclays.exception;

public class PaymentsException extends Exception {

	private static final long serialVersionUID = 1L;

	public PaymentsException(String message) {
		super(message);
		
	}
	
}
